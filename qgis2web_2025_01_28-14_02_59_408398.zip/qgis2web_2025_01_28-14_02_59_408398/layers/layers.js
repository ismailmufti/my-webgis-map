var wms_layers = [];


        var lyr_OSMStandard_0 = new ol.layer.Tile({
            'title': 'OSM Standard',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' &middot; <a href="https://www.openstreetmap.org/copyright">© OpenStreetMap contributors, CC-BY-SA</a>',
                url: 'http://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_kelompok_1 = new ol.format.GeoJSON();
var features_kelompok_1 = format_kelompok_1.readFeatures(json_kelompok_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_kelompok_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_kelompok_1.addFeatures(features_kelompok_1);
var lyr_kelompok_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_kelompok_1, 
                style: style_kelompok_1,
                popuplayertitle: 'kelompok',
                interactive: true,
    title: 'kelompok<br />\
    <img src="styles/legend/kelompok_1_0.png" /> 10<br />\
    <img src="styles/legend/kelompok_1_1.png" /> 20<br />\
    <img src="styles/legend/kelompok_1_2.png" /> 30<br />\
    <img src="styles/legend/kelompok_1_3.png" /> 40<br />\
    <img src="styles/legend/kelompok_1_4.png" /> <br />'
        });
var format_alamat_2 = new ol.format.GeoJSON();
var features_alamat_2 = format_alamat_2.readFeatures(json_alamat_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_alamat_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_alamat_2.addFeatures(features_alamat_2);
var lyr_alamat_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_alamat_2, 
                style: style_alamat_2,
                popuplayertitle: 'alamat',
                interactive: true,
    title: 'alamat<br />\
    <img src="styles/legend/alamat_2_0.png" /> 101<br />\
    <img src="styles/legend/alamat_2_1.png" /> 102<br />\
    <img src="styles/legend/alamat_2_2.png" /> 103<br />\
    <img src="styles/legend/alamat_2_3.png" /> 104<br />\
    <img src="styles/legend/alamat_2_4.png" /> 105<br />\
    <img src="styles/legend/alamat_2_5.png" /> 106<br />\
    <img src="styles/legend/alamat_2_6.png" /> 107<br />\
    <img src="styles/legend/alamat_2_7.png" /> 108<br />\
    <img src="styles/legend/alamat_2_8.png" /> 109<br />\
    <img src="styles/legend/alamat_2_9.png" /> 110<br />\
    <img src="styles/legend/alamat_2_10.png" /> 111<br />\
    <img src="styles/legend/alamat_2_11.png" /> 112<br />\
    <img src="styles/legend/alamat_2_12.png" /> 401<br />\
    <img src="styles/legend/alamat_2_13.png" /> 402<br />\
    <img src="styles/legend/alamat_2_14.png" /> 403<br />\
    <img src="styles/legend/alamat_2_15.png" /> 404<br />\
    <img src="styles/legend/alamat_2_16.png" /> 405<br />\
    <img src="styles/legend/alamat_2_17.png" /> 406<br />\
    <img src="styles/legend/alamat_2_18.png" /> 407<br />\
    <img src="styles/legend/alamat_2_19.png" /> 408<br />\
    <img src="styles/legend/alamat_2_20.png" /> 409<br />\
    <img src="styles/legend/alamat_2_21.png" /> 410<br />\
    <img src="styles/legend/alamat_2_22.png" /> 411<br />\
    <img src="styles/legend/alamat_2_23.png" /> 412<br />\
    <img src="styles/legend/alamat_2_24.png" /> 413<br />\
    <img src="styles/legend/alamat_2_25.png" /> 414<br />\
    <img src="styles/legend/alamat_2_26.png" /> 501<br />\
    <img src="styles/legend/alamat_2_27.png" /> 502<br />\
    <img src="styles/legend/alamat_2_28.png" /> 503<br />\
    <img src="styles/legend/alamat_2_29.png" /> 504<br />\
    <img src="styles/legend/alamat_2_30.png" /> 505<br />\
    <img src="styles/legend/alamat_2_31.png" /> 506<br />\
    <img src="styles/legend/alamat_2_32.png" /> 507<br />\
    <img src="styles/legend/alamat_2_33.png" /> 508<br />\
    <img src="styles/legend/alamat_2_34.png" /> 509<br />\
    <img src="styles/legend/alamat_2_35.png" /> 510<br />\
    <img src="styles/legend/alamat_2_36.png" /> 544<br />\
    <img src="styles/legend/alamat_2_37.png" /> 566<br />\
    <img src="styles/legend/alamat_2_38.png" /> 701<br />\
    <img src="styles/legend/alamat_2_39.png" /> 702<br />\
    <img src="styles/legend/alamat_2_40.png" /> 703<br />\
    <img src="styles/legend/alamat_2_41.png" /> 704<br />\
    <img src="styles/legend/alamat_2_42.png" /> 801<br />\
    <img src="styles/legend/alamat_2_43.png" /> 802<br />\
    <img src="styles/legend/alamat_2_44.png" /> 803<br />\
    <img src="styles/legend/alamat_2_45.png" /> 804<br />\
    <img src="styles/legend/alamat_2_46.png" /> 805<br />\
    <img src="styles/legend/alamat_2_47.png" /> 806<br />\
    <img src="styles/legend/alamat_2_48.png" /> 807<br />\
    <img src="styles/legend/alamat_2_49.png" /> 901<br />\
    <img src="styles/legend/alamat_2_50.png" /> 902<br />\
    <img src="styles/legend/alamat_2_51.png" /> 903<br />\
    <img src="styles/legend/alamat_2_52.png" /> 904<br />\
    <img src="styles/legend/alamat_2_53.png" /> 905<br />\
    <img src="styles/legend/alamat_2_54.png" /> 906<br />\
    <img src="styles/legend/alamat_2_55.png" /> 907<br />\
    <img src="styles/legend/alamat_2_56.png" /> 908<br />\
    <img src="styles/legend/alamat_2_57.png" /> 909<br />\
    <img src="styles/legend/alamat_2_58.png" /> 910<br />\
    <img src="styles/legend/alamat_2_59.png" /> 911<br />\
    <img src="styles/legend/alamat_2_60.png" /> 912<br />\
    <img src="styles/legend/alamat_2_61.png" /> 1001<br />\
    <img src="styles/legend/alamat_2_62.png" /> 1002<br />\
    <img src="styles/legend/alamat_2_63.png" /> 1003<br />\
    <img src="styles/legend/alamat_2_64.png" /> 1004<br />\
    <img src="styles/legend/alamat_2_65.png" /> 1005<br />\
    <img src="styles/legend/alamat_2_66.png" /> <br />'
        });

lyr_OSMStandard_0.setVisible(true);lyr_kelompok_1.setVisible(true);lyr_alamat_2.setVisible(true);
var layersList = [lyr_OSMStandard_0,lyr_kelompok_1,lyr_alamat_2];
lyr_kelompok_1.set('fieldAliases', {'NOLANG': 'NOLANG', 'ZONE': 'ZONE', 'SUBZONE': 'SUBZONE', 'LOKASI': 'LOKASI', 'JENIS_PLG': 'JENIS_PLG', 'NAMA': 'NAMA', 'ALAMAT': 'ALAMAT', 'PEM': 'PEM', 'POS_LAT': 'POS_LAT', 'POS_LONG': 'POS_LONG', });
lyr_alamat_2.set('fieldAliases', {'NOLANG': 'NOLANG', 'ZONE': 'ZONE', 'SUBZONE': 'SUBZONE', 'LOKASI': 'LOKASI', 'JENIS_PLG': 'JENIS_PLG', 'NAMA': 'NAMA', 'ALAMAT': 'ALAMAT', 'PEM': 'PEM', 'POS_LAT': 'POS_LAT', 'POS_LONG': 'POS_LONG', });
lyr_kelompok_1.set('fieldImages', {'NOLANG': 'Range', 'ZONE': 'Range', 'SUBZONE': 'Range', 'LOKASI': 'Range', 'JENIS_PLG': 'Range', 'NAMA': 'TextEdit', 'ALAMAT': 'TextEdit', 'PEM': 'Range', 'POS_LAT': 'TextEdit', 'POS_LONG': 'TextEdit', });
lyr_alamat_2.set('fieldImages', {'NOLANG': 'Range', 'ZONE': 'Range', 'SUBZONE': 'Range', 'LOKASI': 'Range', 'JENIS_PLG': 'Range', 'NAMA': 'TextEdit', 'ALAMAT': 'TextEdit', 'PEM': 'Range', 'POS_LAT': 'TextEdit', 'POS_LONG': 'TextEdit', });
lyr_kelompok_1.set('fieldLabels', {'NOLANG': 'inline label - visible with data', 'ZONE': 'inline label - visible with data', 'SUBZONE': 'inline label - visible with data', 'LOKASI': 'inline label - visible with data', 'JENIS_PLG': 'inline label - visible with data', 'NAMA': 'inline label - visible with data', 'ALAMAT': 'inline label - visible with data', 'PEM': 'inline label - visible with data', 'POS_LAT': 'inline label - visible with data', 'POS_LONG': 'inline label - visible with data', });
lyr_alamat_2.set('fieldLabels', {'NOLANG': 'inline label - visible with data', 'ZONE': 'inline label - visible with data', 'SUBZONE': 'inline label - visible with data', 'LOKASI': 'inline label - visible with data', 'JENIS_PLG': 'inline label - visible with data', 'NAMA': 'inline label - visible with data', 'ALAMAT': 'inline label - visible with data', 'PEM': 'inline label - visible with data', 'POS_LAT': 'inline label - visible with data', 'POS_LONG': 'inline label - visible with data', });
lyr_alamat_2.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});